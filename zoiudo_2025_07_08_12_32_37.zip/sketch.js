function setup() {
  createCanvas(400, 400);
}let olhoX;
let olhoY;

function draw() {
  background(220);
  fill('#B97510');
  circle(240,240,240)
  fill('withe')
  circle(130, 150, 90)
  fill('white')
  circle(245, 150, 90)
  fill('pink')
  circle(200, 270, 80)
  fill('#1583B4')
   
  olhoX = map(mouseX, 0, 400, 130, 170);
  olhoY = map(mouseY, 0, 400, 130, 170);

  circle(olhoX, olhoY, 10); 
  circle(olhoX + 100, olhoY, 10); 
} 