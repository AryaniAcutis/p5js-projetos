function setup() {
  createCanvas(400, 400);
}
function setup() {
  createCanvas(400, 400);
let xJogador1 = 0;
let xJogador2 = 0;
let xJogador3 = 0;
let xJogador4 = 0;

 function draw() {
  background(220);
  textSize(40)
  text("function setup() {
  createCanvas(400, 400);
   
", xJogador1, 80);
  text("🦁🟥", xJogador2, 180);
  text("🦅🟦", xJogador3, 280);
  text("🦡🟨", xJogador4, 380);
  rect(350, 0, 10, 400);
  xJogador1 += random(5);
  xJogador2 += random(5);
  xJogador3 += random(5);
  xJogador4 += random(5);

  if (xJogador1 > 350) {
    text("sonserina venceu!", 50, 200);
    noLoop();
  }
  if (xJogador2 > 350) {
    text("grifnória venceu!", 50, 200);
    noLoop();
  }
 if (xJogador3 > 350) {
    text("corvinal venceu!", 50, 200);
    noLoop();
}  if (xJogador4 > 350) {
    text("lufa-lufa venceu!", 50, 200);
    noLoop();
  }