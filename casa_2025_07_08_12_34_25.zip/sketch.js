function setup() {
  createCanvas(800, 800);
}
function draw() {
  fill('#795548')
  background(220) 
  triangle(80,400, 275, 250, 500, 400)
  fill('#00BCD4')
 square(130, 400, 300);}
 fill
 ellipse(50, 50, 80, 80);
triangle(30, 75, 58, 20, 86, 70);
