let campoIdade;
let campoFantasia;
let campoAventura;
let campoDrama;

function setup() {
  createCanvas(800, 400);
  createElement("h2", "Recomendador de filmes");
  createSpan("Sua idade:");
  campoIdade = createInput("5");
  campoFantasia = createCheckbox("Gosta de fantasia?");
  campoAventura = createCheckbox("Gosta de aventura?");
  campoDrama = createCheckbox("Gosta de Drama?");
}

function draw() {
  background("white");
  let idade = campoIdade.value();
  let gostaDeFantasia = campoFantasia.checked();
  let gostaDeAventura = campoAventura.checked();
  let gostaDeDrama= campoDrama.checked();
  let recomendacao = geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura, gostaDeDrama);

  fill(color(76, 0, 115));
  textAlign(CENTER, CENTER);
  textSize(38);
  text(recomendacao, width / 3, height / 3);
}

function geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura, gostaDeDrama) {
  if (idade >= 10) {
    if (idade >= 14) {
      return "              Animais fantásticos e onde habitam";
    } else {
      if (idade >= 12) {
        if(gostaDeFantasia || gostaDeAventura) {
          return "               Homem aranha: no aranhaverso";          
        } else{
         return "                   A Fantástica fabrica de Chocolate";
        }
      } else {
        if (gostaDeFantasia) {
          return "O Rei Leão (2019)";
        } else {
          return "A Bella e a Fera(2017)";
        }
      }
    }
  } else {
    if (gostaDeFantasia) {
      return "                    Harry Potter e o Prisioneiro de Askabam";
    } else {
      return "                  Percy Jakcson e o Ladrão de Raios";
    }
  }
}

  